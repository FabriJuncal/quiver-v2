# Actualización Guided Mode — AI Software Factory v2

Este paquete contiene los archivos que deben reemplazarse dentro de tu copia local de **AI Software Factory v2** para incorporar:

- Guided Mode;
- Decision Boundaries;
- Next Action State;
- reanudación automática;
- comunicación guiada;
- reducción de preguntas innecesarias.

---

# Archivos a reemplazar

Suponiendo que tu Factory está en:

```text
~/Projects/ai-software-factory/
```

reemplazar:

## 1

Origen de este paquete:

```text
workflow/00_SHARED_CONTRACT.md
```

Destino:

```text
~/Projects/ai-software-factory/workflow/00_SHARED_CONTRACT.md
```

---

## 2

Origen:

```text
workflow/10_RESUME.md
```

Destino:

```text
~/Projects/ai-software-factory/workflow/10_RESUME.md
```

---

## 3

Origen:

```text
templates/PROJECT_STATE.md
```

Destino:

```text
~/Projects/ai-software-factory/templates/PROJECT_STATE.md
```

---

## 4

Origen:

```text
templates/requirement/STATE.md
```

Destino:

```text
~/Projects/ai-software-factory/templates/requirement/STATE.md
```

---

## 5

Origen:

```text
templates/AGENTS.md
```

Destino:

```text
~/Projects/ai-software-factory/templates/AGENTS.md
```

---

# Copia mediante Terminal

Si descomprimiste este paquete y estás parado en su raíz:

```bash
FACTORY="$HOME/Projects/ai-software-factory"
```

Crear backups:

```bash
cp "$FACTORY/workflow/00_SHARED_CONTRACT.md" "$FACTORY/workflow/00_SHARED_CONTRACT.md.bak"
cp "$FACTORY/workflow/10_RESUME.md" "$FACTORY/workflow/10_RESUME.md.bak"
cp "$FACTORY/templates/PROJECT_STATE.md" "$FACTORY/templates/PROJECT_STATE.md.bak"
cp "$FACTORY/templates/requirement/STATE.md" "$FACTORY/templates/requirement/STATE.md.bak"
cp "$FACTORY/templates/AGENTS.md" "$FACTORY/templates/AGENTS.md.bak"
```

Reemplazar:

```bash
cp workflow/00_SHARED_CONTRACT.md "$FACTORY/workflow/00_SHARED_CONTRACT.md"
cp workflow/10_RESUME.md "$FACTORY/workflow/10_RESUME.md"
cp templates/PROJECT_STATE.md "$FACTORY/templates/PROJECT_STATE.md"
cp templates/requirement/STATE.md "$FACTORY/templates/requirement/STATE.md"
cp templates/AGENTS.md "$FACTORY/templates/AGENTS.md"
```

---

# Después de reemplazar los archivos

## 1. Actualizar ~/.codex/AGENTS.md

Agregar la sección de Guided Mode definida en la guía de configuración global de AI Software Factory.

Como mínimo debe indicar:

- avanzar automáticamente hasta el próximo Decision Boundary;
- no preguntar genéricamente cómo continuar;
- persistir `Next action`;
- continuar cuando `User action required: false`;
- detenerse ante decisiones, approvals, bloqueos o acciones irreversibles.

Después reiniciar Codex.

---

## 2. Proyectos ya inicializados

Los proyectos creados antes de esta actualización todavía pueden tener templates viejos.

Dentro de cada proyecto existente, pedir a Codex:

```text
Actualizá únicamente la capa de AI Software Factory de este proyecto para adoptar Guided Mode.

No modifiques código de aplicación ni decisiones ya aprobadas.

Adaptá:

- AGENTS.md
- PROJECT_STATE.md
- los STATE.md activos de docs/requirements/

al nuevo formato.

Conservá toda la información existente.

Agregá:
- fase actual;
- próxima acción;
- motivo;
- user action required;
- expected output;
- after this;
- resume instruction.

Después revisá el estado y continuá automáticamente si la próxima acción no requiere una decisión mía.
```

---

# Verificación

En una nueva sesión de Codex preguntar:

```text
Revisá PROJECT_STATE.md y el STATE del requirement activo.

Explicá brevemente dónde estamos.

Si la próxima acción no requiere una decisión mía, continuá automáticamente.
```

El comportamiento esperado es:

```text
Estado
→ próxima acción
→ ACCIÓN DEL USUARIO: ninguna
→ ejecución automática
```

y no:

```text
Resumen
→ "¿Cómo continuamos?"
```

---

# Principio final

AI Software Factory debe funcionar como una guía activa:

> **La Factory propone y avanza. El usuario decide en los puntos que realmente requieren una decisión.**
